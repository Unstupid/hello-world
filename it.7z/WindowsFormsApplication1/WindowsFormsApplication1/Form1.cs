﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            HelloWorld(2);
            InitializeComponent();
        }
        private static string HelloWorld(int NoOfTimes)
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Hello World!");
            }
            Console.ReadLine();
        }
    }
    class Member
    {
        public string Name { get; set; }
    }
}
