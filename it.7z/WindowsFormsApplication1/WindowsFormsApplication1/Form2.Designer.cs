﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLogInAs = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.txtAllotmentNumber = new System.Windows.Forms.TextBox();
            this.SurnameLabel = new System.Windows.Forms.Label();
            this.FirstNameLabel = new System.Windows.Forms.Label();
            this.LogInAsLabel = new System.Windows.Forms.Label();
            this.AllotmentNumber = new System.Windows.Forms.Label();
            this.btn_Next = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtLogInAs
            // 
            this.txtLogInAs.Location = new System.Drawing.Point(116, 139);
            this.txtLogInAs.Name = "txtLogInAs";
            this.txtLogInAs.Size = new System.Drawing.Size(127, 20);
            this.txtLogInAs.TabIndex = 13;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(116, 23);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(127, 20);
            this.txtFirstName.TabIndex = 12;
            // 
            // txtSurname
            // 
            this.txtSurname.Location = new System.Drawing.Point(116, 61);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(127, 20);
            this.txtSurname.TabIndex = 11;
            // 
            // txtAllotmentNumber
            // 
            this.txtAllotmentNumber.Location = new System.Drawing.Point(116, 100);
            this.txtAllotmentNumber.Name = "txtAllotmentNumber";
            this.txtAllotmentNumber.Size = new System.Drawing.Size(127, 20);
            this.txtAllotmentNumber.TabIndex = 10;
            // 
            // SurnameLabel
            // 
            this.SurnameLabel.AutoSize = true;
            this.SurnameLabel.Location = new System.Drawing.Point(12, 68);
            this.SurnameLabel.Name = "SurnameLabel";
            this.SurnameLabel.Size = new System.Drawing.Size(49, 13);
            this.SurnameLabel.TabIndex = 14;
            this.SurnameLabel.Text = "Surname";
            this.SurnameLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.Location = new System.Drawing.Point(12, 30);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(57, 13);
            this.FirstNameLabel.TabIndex = 15;
            this.FirstNameLabel.Text = "First Name";
            // 
            // LogInAsLabel
            // 
            this.LogInAsLabel.AutoSize = true;
            this.LogInAsLabel.Location = new System.Drawing.Point(12, 146);
            this.LogInAsLabel.Name = "LogInAsLabel";
            this.LogInAsLabel.Size = new System.Drawing.Size(50, 13);
            this.LogInAsLabel.TabIndex = 16;
            this.LogInAsLabel.Text = "Log in as";
            // 
            // AllotmentNumber
            // 
            this.AllotmentNumber.AutoSize = true;
            this.AllotmentNumber.Location = new System.Drawing.Point(12, 107);
            this.AllotmentNumber.Name = "AllotmentNumber";
            this.AllotmentNumber.Size = new System.Drawing.Size(90, 13);
            this.AllotmentNumber.TabIndex = 17;
            this.AllotmentNumber.Text = "Allotment Number";
            // 
            // btn_Next
            // 
            this.btn_Next.Location = new System.Drawing.Point(80, 197);
            this.btn_Next.Name = "btn_Next";
            this.btn_Next.Size = new System.Drawing.Size(75, 23);
            this.btn_Next.TabIndex = 18;
            this.btn_Next.Text = "Next Record";
            this.btn_Next.UseVisualStyleBackColor = true;
            this.btn_Next.Click += new System.EventHandler(this.btn_Next_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btn_Next);
            this.Controls.Add(this.AllotmentNumber);
            this.Controls.Add(this.LogInAsLabel);
            this.Controls.Add(this.FirstNameLabel);
            this.Controls.Add(this.SurnameLabel);
            this.Controls.Add(this.txtLogInAs);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.txtSurname);
            this.Controls.Add(this.txtAllotmentNumber);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLogInAs;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.TextBox txtAllotmentNumber;
        private System.Windows.Forms.Label SurnameLabel;
        private System.Windows.Forms.Label FirstNameLabel;
        private System.Windows.Forms.Label LogInAsLabel;
        private System.Windows.Forms.Label AllotmentNumber;
        private System.Windows.Forms.Button btn_Next;
    }
}