﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        private void NavigateRecords()
        {
            dRow = ds.Tables[0].Rows[inc];

            txtFirstName.Text = dRow.ItemArray.GetValue(1).ToString();
            txtSurname.Text = dRow.ItemArray.GetValue(2).ToString();
            txtAllotmentNumber.Text = dRow.ItemArray.GetValue(3).ToString();
            txtLogInAs.Text = dRow.ItemArray.GetValue(4).ToString();
        }
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Hello World!");
            Console.ReadLine();
           
        }

        DatabaseConnection objConnect;
        string conString;
        DataSet ds;
        DataRow dRow;
        int MaxRows;
        int inc = 0;

        private void Form2_Load(object sender, EventArgs e)
        {

            try
            {
                objConnect = new DatabaseConnection();
                conString = Properties.Settings.Default.MemberTable;
                objConnect.connection_string = conString;
                objConnect.Sql = Properties.Settings.Default.SQL;
                ds = objConnect.GetConnection;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void btn_Next_Click(object sender, EventArgs e)
        {
            if (inc != MaxRows - 1)
            {
                inc++;
                NavigateRecords();
            }
        }
    }
}
