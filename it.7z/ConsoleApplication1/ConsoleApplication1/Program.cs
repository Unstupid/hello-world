﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Car myCar = new Car();
            myCar.Maker = "Vauxhall";
            myCar.Age = 10;
            myCar.Type = "Corsa";
            myCar.Colour = "Yellow";
            Console.WriteLine("A car that you are looking for is a {0} {1} {2} that is {3} years old",
                myCar.Colour, myCar.Maker, myCar.Type, myCar.Age);
            Console.ReadLine();
            do
            {

                try
                {
                    Console.WriteLine("Would you like to check the value of that car? Press y to confirm or n to deny.");
                    public string ValueCheck = Console.ReadLine();
                }
                catch (ArgumentException ArgEx)
                {
                    Console.WriteLine("That wasn't a string."); 

                    Console.WriteLine(ArgEx.Message);
                    public  bool Repeat = true;
                }
                finally
                {
                    Console.Writeline("HI");
                }

            } while (Repeat);
            if (ValueCheck = "y")
            {
                Console.WriteLine("Your car is worth "+ 40000*(1/myCar.Age) +" pounds.");
            }
            else if (ValueCheck = "n") {
                Console.WriteLine("OK Then");
            } else {
                Console.WriteLine("y or n only please");
            }       
        }
    }
    class Car
    {
        public string Maker { get; set; }
        public string Type { get; set; }
        public int Age { get; set; }
        public string Colour { get; set; }
    }
}
